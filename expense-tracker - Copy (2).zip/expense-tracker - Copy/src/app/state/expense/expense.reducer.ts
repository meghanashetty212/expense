// state/expenses/expense.reducer.ts
import { Action, createReducer, on } from '@ngrx/store';
import { Expense } from './expense.model';
import { loadExpensesSuccess, addExpense, updateExpense, deleteExpense } from './expense.action';

export interface ExpenseState {
  expenses: Expense[];
}

const initialState: ExpenseState = {
  expenses: []
};

const _expenseReducer = createReducer(
  initialState,
  on(loadExpensesSuccess, (state, { expenses }) => ({ ...state, expenses })),
  on(addExpense, (state, { expense }) => ({ ...state, expenses: [...state.expenses, expense] })),
  on(updateExpense, (state, { expense }) => ({
    ...state,
    expenses: state.expenses.map(e => e.id === expense.id ? expense : e)
  })),
  on(deleteExpense, (state, { id }) => ({
    ...state,
    expenses: state.expenses.filter(e => e.id !== id)
  }))
);

export function expenseReducer(state: ExpenseState | undefined, action: Action) {
  return _expenseReducer(state, action);
}
