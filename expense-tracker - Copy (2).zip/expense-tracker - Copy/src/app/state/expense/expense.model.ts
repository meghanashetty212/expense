// state/expenses/expense.model.ts
export interface Expense {
    id: number;
    description: string;
    amount: number;
    currency: string;
  }
  