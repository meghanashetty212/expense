// state/expenses/expense.effects.ts
import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { ExpenseService } from '../../services/expense.service';
import { loadExpenses, loadExpensesSuccess, addExpense, updateExpense, deleteExpense } from './expense.action';
import { mergeMap, map } from 'rxjs/operators';

@Injectable()
export class ExpenseEffects {
  loadExpenses$ = createEffect(() =>
    this.actions$.pipe(
      ofType(loadExpenses),
      mergeMap(() => this.expenseService.getExpenses().pipe(
        map(expenses => loadExpensesSuccess({ expenses }))
      ))
    )
  );

  constructor(private actions$: Actions, private expenseService: ExpenseService) { }
}
