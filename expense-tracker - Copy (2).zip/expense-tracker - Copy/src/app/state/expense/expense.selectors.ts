// state/expenses/expense.selectors.ts
import { createSelector, createFeatureSelector } from '@ngrx/store';
import { ExpenseState } from './expense.reducer';

export const selectExpenseState = createFeatureSelector<ExpenseState>('expenses');

export const selectAllExpenses = createSelector(
  selectExpenseState,
  (state: ExpenseState) => state.expenses
);
