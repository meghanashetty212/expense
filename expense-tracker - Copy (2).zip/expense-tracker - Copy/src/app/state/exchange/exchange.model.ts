// state/exchange/exchange.model.ts
export interface ExchangeRate {
    base: string;
    rates: { [key: string]: number };
    date: string;
  }
  