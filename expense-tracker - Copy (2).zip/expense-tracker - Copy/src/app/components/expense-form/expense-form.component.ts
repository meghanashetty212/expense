// components/expense-form/expense-form.component.ts
import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { addExpense } from '../../state/expense/expense.action';
import { Expense } from '../../state/expense/expense.model';

@Component({
  selector: 'app-expense-form',
  templateUrl: './expense-form.component.html',
  styleUrls: ['./expense-form.component.css']
})
export class ExpenseFormComponent {
  expenseForm: FormGroup;

  constructor(private fb: FormBuilder, private store: Store) {
    this.expenseForm = this.fb.group({
      description: ['', Validators.required],
      amount: ['', [Validators.required, Validators.pattern('^[0-9]+(.[0-9]{1,2})?$')]],
      currency: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.expenseForm.valid) {
      const expense: Expense = this.expenseForm.value;
      this.store.dispatch(addExpense({ expense }));
      this.expenseForm.reset();
    }
   
  }
}
