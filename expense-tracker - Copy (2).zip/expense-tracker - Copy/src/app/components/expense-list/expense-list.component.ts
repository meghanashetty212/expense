// components/expense-list/expense-list.component.ts
import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Expense } from '../../state/expense/expense.model';

import { loadExpenses, deleteExpense } from '../../state/expense/expense.action';

@Component({
  selector: 'app-expense-list',
  templateUrl: './expense-list.component.html',
  styleUrls: ['./expense-list.component.css']
})
export class ExpenseListComponent implements OnInit {
  expenses$: Observable<Expense[]>;

  constructor(private store: Store<{ expenses: Expense[] }>) {
    this.expenses$ = store.select('expenses');
  }

  ngOnInit(): void {
    this.store.dispatch(loadExpenses());
  }

  onDelete(id: number): void {
    this.store.dispatch(deleteExpense({ id }));
  }
}
